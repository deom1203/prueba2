//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int{
    
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    init( velocidadInicial : Velocidades){
        
        self = velocidadInicial
    }
}

class Auto {
    
    var velocidad : Velocidades
    
    init(velocidad : Velocidades) {
        
        self .velocidad = .Apagado
    }
    
    func cambioDeVelocidad( ) -> ( actual : Int, velocidadEnCadena : String){
        
        var velocidadEnCadena = ""
        
        if velocidad == .Apagado{
            
            velocidad = .VelocidadBaja
            velocidadEnCadena = "Velocidad Baja"
        }else if velocidad == .VelocidadBaja{
            
            velocidad = .VelocidadMedia
            velocidadEnCadena = "Velocidad Media"
        }else if velocidad == .VelocidadMedia{
            
            velocidad = .VelocidadAlta
            velocidadEnCadena = "Velocidad Alta"
        }else if velocidad == .VelocidadAlta{
            
            velocidad = .VelocidadMedia
            velocidadEnCadena = "Velocidad Media"
        }
        
        let resultado = (velocidad.rawValue, velocidadEnCadena)
        
        return resultado
    }
    
}

var auto = Auto(velocidad: .Apagado)

for i in 1...20{
    
    Auto.cambioDeVelocidad(auto)
    print("\(auto.cambioDeVelocidad())")
}
